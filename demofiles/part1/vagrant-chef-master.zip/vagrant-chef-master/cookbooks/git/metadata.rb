name "git"

depends "apt"
