include_recipe "percona::apt_repository"
include_recipe "percona::client"
include_recipe "percona::server"