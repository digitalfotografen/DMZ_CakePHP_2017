name "system"

depends "percona"
depends "php"
depends "redis"
