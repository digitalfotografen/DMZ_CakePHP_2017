name "nginx"

depends "apt"
