include_recipe "postgresql::apt_repository"
include_recipe "postgresql::client"
include_recipe "postgresql::server"
