default['php']['composer']['url'] = "https://getcomposer.org/composer.phar"
default['php']['composer']['bin'] = "/usr/local/bin/composer"
