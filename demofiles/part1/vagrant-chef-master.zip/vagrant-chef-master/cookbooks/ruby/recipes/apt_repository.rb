apt_repository "brightbox" do
  key "C3173AA6"
  uri "ppa:brightbox/ruby-ng"
  components ["main"]
end
