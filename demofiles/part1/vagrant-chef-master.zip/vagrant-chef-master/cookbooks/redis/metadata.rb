name "redis"

depends "apt"
